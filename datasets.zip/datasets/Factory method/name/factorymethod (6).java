
public UMLNodeViewer(PackageSummary summary, ClassDiagramReloader init) {
    super(null);
    diagram = new UMLPackage(summary);
    reloader = init;
    reloader.add(diagram);
}
.....
.....
public abstract class Creator {
    public abstract Product createProduct();
}

public class ConcreteCreatorA extends Creator {
    @Override
    public Product createProduct() {
        return new ConcreteProductA();
    }
}

public class ConcreteCreatorB extends Creator {
    @Override
    public Product createProduct() {
        return new ConcreteProductB();
    }
}
